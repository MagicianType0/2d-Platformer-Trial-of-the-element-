﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SettingsMenu : MonoBehaviour
{

    Resolution[] resolutions;

    public TMP_Dropdown resolutiondropdown;

    public Toggle FullscreenToggle;

    public PlayerPrefs SaveSettings;
    void Start()
    {
       // PlayerPrefs.SetFloat("Resolution", 566f);

       // float something = PlayerPrefs.GetFloat("Resolution");


       

        Screen.fullScreen = PlayerPrefs.GetInt("Fullscreen") == 1? true : false;




        if (FullscreenToggle != null)
        {
            FullscreenToggle.isOn = Screen.fullScreen;
        }
      resolutions = Screen.resolutions;
        resolutiondropdown.ClearOptions();

        int currentResolutionIndex = 0;
        List<string> options = new List<string>();
        for (int i = 0; i < resolutions.Length; i++)
        {
            string option = resolutions[i].width + " x " + resolutions[i].height;
            options.Add(option);

            if (resolutions[i].width == Screen.currentResolution.width && resolutions[i].width == Screen.currentResolution.height)
            {
                currentResolutionIndex = i;
            }
        }

        resolutiondropdown.AddOptions(options);
        resolutiondropdown.value = currentResolutionIndex;
        resolutiondropdown.RefreshShownValue();
    }
    public void SetResolution(int resolutionIndex)
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
        PlayerPrefs.SetInt("ResolutionX", resolution.width);
        PlayerPrefs.SetInt("ResolutionY", resolution.height);
    }
    public void Setquality(int qualityIndex)
    {
        QualitySettings.SetQualityLevel(qualityIndex);
    }

    public void SetFullScreen(bool isFullscreen)
    {

        Screen.fullScreen = isFullscreen;

        PlayerPrefs.SetInt("Fullscreen", Screen.fullScreen ? 1 : 0);
    }
}
